#include "blake3_quick.h"

uint64_t blake3_hash64(const void *data, size_t bytes) {
	uint64_t final = 0;
	uint8_t output[8];
	blake3_hasher hasher;
	blake3_hasher_init(&hasher);
	blake3_hasher_update(&hasher, data, bytes);
	blake3_hasher_finalize(&hasher, output, 8);
	for (int i = 0; i < 8; i++)
		final = (final << 8) + output[i];
	return final;
}

blake3_hash_block blake3_hash(const void *data, size_t bytes) {
	blake3_hash_block hash;
	blake3_hasher hasher;
	blake3_hasher_init(&hasher);
	blake3_hasher_update(&hasher, data, bytes);
	blake3_hasher_finalize(&hasher, hash.hash, 8);
	return hash;
}
