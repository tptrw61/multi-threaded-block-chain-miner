#ifndef BLAKE3_QUICK_H
#define BLAKE3_QUICK_H

#include <blake3.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
	uint8_t hash[BLAKE3_OUT_LEN];
} blake3_hash_block;

uint64_t blake3_hash64(const void *data, size_t bytes);
blake3_hash_block blake3_hash(const void *data, size_t bytes);


#ifdef __cplusplus
}
#endif
#endif /* BLAKE3_QUICK_H */
